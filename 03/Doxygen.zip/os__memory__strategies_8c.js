var os__memory__strategies_8c =
[
    [ "os_Memory_BestFit", "os__memory__strategies_8c.html#a32dce4154a39058eb1a3fd339b7182fa", null ],
    [ "os_Memory_FirstFit", "os__memory__strategies_8c.html#a4b01ab696c0d0343e82e40dd358bc364", null ],
    [ "os_Memory_NextFit", "os__memory__strategies_8c.html#a650a0b39718d09cdddb6dca4d8e47559", null ],
    [ "os_Memory_WorstFit", "os__memory__strategies_8c.html#a93dfc62496d6d43e63047930127e7870", null ]
];