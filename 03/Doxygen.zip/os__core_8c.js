var os__core_8c =
[
    [ "os_checkResetSource", "os__core_8c.html#a4005609655750d34e92fce6c062f9f1c", null ],
    [ "os_errorPStr", "os__core_8c.html#a1ed51c8da9054e49d1f14175945cc563", null ],
    [ "os_init", "os__core_8c.html#a6cc2e63d83267ff5059bf0a76b302a09", null ],
    [ "os_init_timer", "os__core_8c.html#a6e2cb65995e0266255572244baf860f3", null ],
    [ "os_initScheduler", "os__core_8c.html#afcd3b8ded93499847533d52c2b08772a", null ],
    [ "os_preInit", "os__core_8c.html#ad6f15cc40e92cda0a376c1be74969681", null ]
];