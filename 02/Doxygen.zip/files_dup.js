var files_dup =
[
    [ "atmega644constants.h", "atmega644constants_8h.html", "atmega644constants_8h" ],
    [ "defines.h", "defines_8h.html", "defines_8h" ],
    [ "lcd.c", "lcd_8c.html", "lcd_8c" ],
    [ "lcd.h", "lcd_8h.html", "lcd_8h" ],
    [ "os_core.c", "os__core_8c.html", "os__core_8c" ],
    [ "os_core.h", "os__core_8h.html", "os__core_8h" ],
    [ "os_input.c", "os__input_8c.html", "os__input_8c" ],
    [ "os_input.h", "os__input_8h.html", "os__input_8h" ],
    [ "os_process.h", "os__process_8h.html", "os__process_8h" ],
    [ "os_scheduler.c", "os__scheduler_8c.html", "os__scheduler_8c" ],
    [ "os_scheduler.h", "os__scheduler_8h.html", "os__scheduler_8h" ],
    [ "os_scheduling_strategies.c", "os__scheduling__strategies_8c.html", "os__scheduling__strategies_8c" ],
    [ "os_scheduling_strategies.h", "os__scheduling__strategies_8h.html", "os__scheduling__strategies_8h" ],
    [ "os_taskman.c", "os__taskman_8c.html", "os__taskman_8c" ],
    [ "os_taskman.h", "os__taskman_8h.html", "os__taskman_8h" ],
    [ "os_user_privileges.h", "os__user__privileges_8h.html", "os__user__privileges_8h" ],
    [ "util.c", "util_8c.html", "util_8c" ],
    [ "util.h", "util_8h.html", "util_8h" ]
];