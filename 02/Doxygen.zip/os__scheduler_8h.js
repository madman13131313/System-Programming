var os__scheduler_8h =
[
    [ "SchedulingStrategy", "os__scheduler_8h.html#ac3ed7aa5fa89d4026cd86e4861ca7963", null ],
    [ "SchedulingStrategy", "os__scheduler_8h.html#a19b2831a25a61b35337be0d5386f1098", null ],
    [ "os_enterCriticalSection", "os__scheduler_8h.html#a9d27b2dbf45ce6648916ed5ceb0a38df", null ],
    [ "os_exec", "os__scheduler_8h.html#a9b7e20809aaf11b9091f711b016e448b", null ],
    [ "os_getCurrentProc", "os__scheduler_8h.html#a917313bbbb324677f26dfdf2ad80de3d", null ],
    [ "os_getNumberOfRegisteredPrograms", "os__scheduler_8h.html#a156ec7e6488be28ea32e937461e16606", null ],
    [ "os_getProcessSlot", "os__scheduler_8h.html#aceff964882db0b41f7e2258ca4d16579", null ],
    [ "os_getSchedulingStrategy", "os__scheduler_8h.html#a4d9935433bba6ee89a4b3b31683d3184", null ],
    [ "os_getStackChecksum", "os__scheduler_8h.html#aaae9c0dde1e830325b558ebfce5864e8", null ],
    [ "os_initScheduler", "os__scheduler_8h.html#afcd3b8ded93499847533d52c2b08772a", null ],
    [ "os_leaveCriticalSection", "os__scheduler_8h.html#a21546fdd22e5e6818e50856a119d98e0", null ],
    [ "os_setSchedulingStrategy", "os__scheduler_8h.html#ad3c4099c5ab03819e77f3de89a1174d2", null ],
    [ "os_startScheduler", "os__scheduler_8h.html#a51223e53b8c2474eeb097b532f167be8", null ]
];