var searchData=
[
  ['mainlabels_91',['mainLabels',['../os__taskman_8c.html#a41e2f4c1204fee51c1d51328959e2a05',1,'os_taskman.c']]],
  ['make_5fpagehandler_92',['make_pagehandler',['../os__taskman_8c.html#a973cce02efa88806528abf08d4f70d1a',1,'make_pagehandler():&#160;os_taskman.c'],['../os__taskman_8c.html#a14f8244535908fb8487e08a0dcd448e6',1,'make_pagehandler(tm_frontpage, tm_null, 0, 0, OS_PR_FRONTPAGE, null, 0):&#160;os_taskman.c'],['../os__taskman_8c.html#a3ab888d5e1057bf1852fb3d5051533fb',1,'make_pagehandler(tm_scheduling_set, tm_null, 0, 0, OS_PR_SCHEDULING, ss, peekStack(1).param):&#160;os_taskman.c']]],
  ['makestrategynamelookup_93',['makeStrategyNameLookup',['../os__taskman_8c.html#a3e7e4dd5e12024f42c44034b78940e2b',1,'os_taskman.c']]],
  ['max_5fnumber_5fof_5fprocesses_94',['MAX_NUMBER_OF_PROCESSES',['../defines_8h.html#a57c4c2d31ce05f6034d5356eb9e366f2',1,'defines.h']]]
];
