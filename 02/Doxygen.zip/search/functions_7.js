var searchData=
[
  ['strategychanger_314',['strategyChanger',['../os__taskman_8c.html#a9f46441635483bb04c2857a3dbfdd925',1,'os_taskman.c']]],
  ['strategyselector_315',['strategySelector',['../os__taskman_8c.html#acf1b1da1d6a9f250f3a0b0e5d57b62ea',1,'os_taskman.c']]]
];
