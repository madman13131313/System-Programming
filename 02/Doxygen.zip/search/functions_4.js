var searchData=
[
  ['make_5fpagehandler_277',['make_pagehandler',['../os__taskman_8c.html#a14f8244535908fb8487e08a0dcd448e6',1,'make_pagehandler(tm_frontpage, tm_null, 0, 0, OS_PR_FRONTPAGE, null, 0):&#160;os_taskman.c'],['../os__taskman_8c.html#a3ab888d5e1057bf1852fb3d5051533fb',1,'make_pagehandler(tm_scheduling_set, tm_null, 0, 0, OS_PR_SCHEDULING, ss, peekStack(1).param):&#160;os_taskman.c']]]
];
