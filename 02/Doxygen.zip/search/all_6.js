var searchData=
[
  ['idle_31',['idle',['../os__scheduler_8c.html#a01131b63acf241e9db91704d89ce15d2',1,'os_scheduler.c']]],
  ['invalid_5fprocess_32',['INVALID_PROCESS',['../defines_8h.html#a455404d0cf6e4ea0b53f9f747e3744b1',1,'defines.h']]],
  ['isanyprocready_33',['isAnyProcReady',['../os__scheduling__strategies_8c.html#a0bb20f041ecb373f5b3c6a36ba1e5ecf',1,'os_scheduling_strategies.c']]],
  ['isr_34',['ISR',['../os__scheduler_8c.html#a5686c229bdef50123688ab6cb1404230',1,'ISR(TIMER2_COMPA_vect):&#160;os_scheduler.c'],['../util_8c.html#add2d7cdddfb682dcc0391e60cf42c7d6',1,'ISR(TIMER0_OVF_vect):&#160;util.c']]]
];
