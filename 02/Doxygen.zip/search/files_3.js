var searchData=
[
  ['os_5fcore_2ec_232',['os_core.c',['../os__core_8c.html',1,'']]],
  ['os_5fcore_2eh_233',['os_core.h',['../os__core_8h.html',1,'']]],
  ['os_5finput_2ec_234',['os_input.c',['../os__input_8c.html',1,'']]],
  ['os_5finput_2eh_235',['os_input.h',['../os__input_8h.html',1,'']]],
  ['os_5fprocess_2eh_236',['os_process.h',['../os__process_8h.html',1,'']]],
  ['os_5fscheduler_2ec_237',['os_scheduler.c',['../os__scheduler_8c.html',1,'']]],
  ['os_5fscheduler_2eh_238',['os_scheduler.h',['../os__scheduler_8h.html',1,'']]],
  ['os_5fscheduling_5fstrategies_2ec_239',['os_scheduling_strategies.c',['../os__scheduling__strategies_8c.html',1,'']]],
  ['os_5fscheduling_5fstrategies_2eh_240',['os_scheduling_strategies.h',['../os__scheduling__strategies_8h.html',1,'']]],
  ['os_5ftaskman_2ec_241',['os_taskman.c',['../os__taskman_8c.html',1,'']]],
  ['os_5ftaskman_2eh_242',['os_taskman.h',['../os__taskman_8h.html',1,'']]],
  ['os_5fuser_5fprivileges_2eh_243',['os_user_privileges.h',['../os__user__privileges_8h.html',1,'']]]
];
