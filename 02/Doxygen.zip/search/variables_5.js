var searchData=
[
  ['os_5fprocesses_328',['os_processes',['../os__scheduler_8c.html#a583b140cea6b7a0bdc6ae1602b1459e2',1,'os_scheduler.c']]],
  ['os_5fsystemtime_5foverflows_329',['os_systemTime_overflows',['../util_8c.html#a3e688a9a5a8266176b9158e289d6d724',1,'util.c']]]
];
