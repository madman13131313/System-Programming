var os__memory_8c =
[
    [ "getHighNibble", "os__memory_8c.html#ae420976ba4abbd069aff795935b9636c", null ],
    [ "getLowNibble", "os__memory_8c.html#a01bd9b56dbbeb0af404043ceca5c8818", null ],
    [ "getOwnerOfChunk", "os__memory_8c.html#ab493cf6ec58f933b4751b0d2a2f77c4a", null ],
    [ "moveChunk", "os__memory_8c.html#a1c8691648bd2d5114b97de7cc2550bc2", null ],
    [ "os_free", "os__memory_8c.html#a345f569e1a9a5d0a6012c76ee1b0f65c", null ],
    [ "os_freeOwnerRestricted", "os__memory_8c.html#ae30934b438eca830815f445a1144a8c2", null ],
    [ "os_freeProcessMemory", "os__memory_8c.html#ac97dfa6f209b8979ac658f93814aa71f", null ],
    [ "os_getAllocationStrategy", "os__memory_8c.html#ac433fde93fe34efce81b77d82ba98773", null ],
    [ "os_getChunkSize", "os__memory_8c.html#af4b11f1dd58f3cec9668a6be98101be4", null ],
    [ "os_getFirstByteOfChunk", "os__memory_8c.html#a292385f9ee19516237f51ab76c76405e", null ],
    [ "os_getMapEntry", "os__memory_8c.html#a29ccc3e0a668c0be4b285bc74ef6d920", null ],
    [ "os_getMapSize", "os__memory_8c.html#a2038e0592b964adafe506b633dd310d6", null ],
    [ "os_getMapStart", "os__memory_8c.html#a3da86607df8a71aee3279f5e3ab99354", null ],
    [ "os_getUseSize", "os__memory_8c.html#af9bbb947c95cfa8b56540b3dd6c88e1c", null ],
    [ "os_getUseStart", "os__memory_8c.html#ade51aae9d1c897a830a2c6c3a4c5b2e6", null ],
    [ "os_malloc", "os__memory_8c.html#a5644c571680a5c019c91c30bee4d5d7e", null ],
    [ "os_realloc", "os__memory_8c.html#aff2d5210e82c9a0452f03876b050535f", null ],
    [ "os_setAllocationStrategy", "os__memory_8c.html#a6e809f1786f114791ae1e8d8abfb39d2", null ],
    [ "setHighNibble", "os__memory_8c.html#a211f98b56ba22e7ec073c1b09b35d0ff", null ],
    [ "setLowNibble", "os__memory_8c.html#a79edcf2881c1b78d097495d05e7cec4f", null ],
    [ "setMapEntry", "os__memory_8c.html#aa0082364f445ac8cfacf8d0e873bcfb5", null ]
];