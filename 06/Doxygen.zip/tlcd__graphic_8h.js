var tlcd__graphic_8h =
[
    [ "Color", "struct_color.html", null ],
    [ "tlcd_changeDrawColor", "tlcd__graphic_8h.html#aacceee845b6c3e2056f1d13d9e506f26", null ],
    [ "tlcd_changePenSize", "tlcd__graphic_8h.html#a0442ea5b2506dbf7085d4e19b5fa21b3", null ],
    [ "tlcd_clearDisplay", "tlcd__graphic_8h.html#a34dc420a98427570ba66be503edfc809", null ],
    [ "tlcd_defineColor", "tlcd__graphic_8h.html#a4b976a4a4598925fd5bf8fe2050f9be7", null ],
    [ "tlcd_defineTouchArea", "tlcd__graphic_8h.html#ad929cd29b11480c304dd5d92542b52d0", null ],
    [ "tlcd_drawBox", "tlcd__graphic_8h.html#ab373f9eac4237c1f7f2971ed4b25fb60", null ],
    [ "tlcd_drawChar", "tlcd__graphic_8h.html#a7467b73390efd95cf090ab814e9bd66a", null ],
    [ "tlcd_drawLine", "tlcd__graphic_8h.html#a939c21ea899281848817287710141303", null ],
    [ "tlcd_drawPoint", "tlcd__graphic_8h.html#a3c0ae97816503b6e4384ef527b52978d", null ],
    [ "tlcd_setCursor", "tlcd__graphic_8h.html#a539d541c7b8057b456d762c98d1f944a", null ]
];