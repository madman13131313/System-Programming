var tlcd__parser_8h =
[
    [ "TouchEvent", "struct_touch_event.html", null ],
    [ "DC1_BYTE", "tlcd__parser_8h.html#a4a1b319deb4ad8fb0bcd04bb8ae44487", null ],
    [ "PENSIZE_INCREASE", "tlcd__parser_8h.html#a046b08c32198dd4d57a07d4555abd38e", null ],
    [ "TOUCHPANEL_EVENT", "tlcd__parser_8h.html#aa5abd59d70624401468f0a439050bff9", null ],
    [ "TouchEventType", "tlcd__parser_8h.html#af9360ba7e12726eabae0c635d317ee6a", null ],
    [ "tlcd_setEventCallback", "tlcd__parser_8h.html#a497209aeb774a789ae745dcb19035639", null ]
];