var searchData=
[
  ['heapoffset_639',['HEAPOFFSET',['../defines_8h.html#a46b527dcb3f8c0858e3d77682fc47b73',1,'defines.h']]],
  ['high_640',['HIGH',['../tlcd__core_8h.html#aadd31e5eb6e891077cb7fd6c906ef4af',1,'tlcd_core.h']]]
];
