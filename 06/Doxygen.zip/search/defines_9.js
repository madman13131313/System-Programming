var searchData=
[
  ['make_5fpagehandler_670',['make_pagehandler',['../os__taskman_8c.html#a973cce02efa88806528abf08d4f70d1a',1,'os_taskman.c']]],
  ['makestrategynamelookup_671',['makeStrategyNameLookup',['../os__taskman_8c.html#a3e7e4dd5e12024f42c44034b78940e2b',1,'os_taskman.c']]],
  ['max_5fnumber_5fof_5fprocesses_672',['MAX_NUMBER_OF_PROCESSES',['../defines_8h.html#a57c4c2d31ce05f6034d5356eb9e366f2',1,'defines.h']]]
];
