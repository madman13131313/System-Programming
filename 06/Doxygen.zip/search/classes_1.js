var searchData=
[
  ['color_347',['Color',['../struct_color.html',1,'']]]
];
