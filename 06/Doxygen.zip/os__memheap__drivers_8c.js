var os__memheap__drivers_8c =
[
    [ "os_getHeapListLength", "os__memheap__drivers_8c.html#a3605704cde0157574ad230b13d4c076b", null ],
    [ "os_initHeaps", "os__memheap__drivers_8c.html#a1735427417a3f887402129714eadcba0", null ],
    [ "os_lookupHeap", "os__memheap__drivers_8c.html#aefde63319f6b0d41036f8cfccf2684c6", null ],
    [ "intHeap__", "os__memheap__drivers_8c.html#ab5abd3b149a45c1de26626e02fd13e78", null ]
];