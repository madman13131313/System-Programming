var tlcd__core_8h =
[
    [ "tlcdBuffer", "structtlcd_buffer.html", null ],
    [ "HIGH", "tlcd__core_8h.html#aadd31e5eb6e891077cb7fd6c906ef4af", null ],
    [ "LOW", "tlcd__core_8h.html#a627b1c92232deafa6370178448d76527", null ],
    [ "tlcd_spi_disable", "tlcd__core_8h.html#a340aa2da010c839c924fb29354785922", null ],
    [ "tlcd_spi_enable", "tlcd__core_8h.html#a56edc480cecfca2496d3a0e862a8f23c", null ],
    [ "TLCD_WIDTH", "tlcd__core_8h.html#af5213aafd60c5b67f7f795b5099f00a3", null ],
    [ "tlcd_hasNextBufferElement", "tlcd__core_8h.html#af8562118e5bdf0415ed41f008a9d4d1b", null ],
    [ "tlcd_init", "tlcd__core_8h.html#a1b4c282d95af652e6ab61a33b65fd9a0", null ],
    [ "tlcd_initBuffer", "tlcd__core_8h.html#ac000cf1a155b511e8187ec8654ec6aee", null ],
    [ "tlcd_readByte", "tlcd__core_8h.html#a9fdfeebbfe9ed030957579fdaac1d93a", null ],
    [ "tlcd_readData", "tlcd__core_8h.html#a7776a849a359c18de1689429f5b87984", null ],
    [ "tlcd_readNextBufferElement", "tlcd__core_8h.html#a89aabb08c61b39f4d93d988306097333", null ],
    [ "tlcd_requestData", "tlcd__core_8h.html#a32a6c0de5f3cafcd446de672ad4c66eb", null ],
    [ "tlcd_reset", "tlcd__core_8h.html#a2c340fed594ac839f7fb63fde9d78fbc", null ],
    [ "tlcd_resetBuffer", "tlcd__core_8h.html#afb698d48de13c7c98bfe72f3f5d51b94", null ],
    [ "tlcd_sendCommand", "tlcd__core_8h.html#a3f58d233f0b03b339ac7650cbbf5c4ee", null ],
    [ "tlcd_writeNextBufferElement", "tlcd__core_8h.html#a50143fb97258911b41c0c076f9448a0f", null ]
];