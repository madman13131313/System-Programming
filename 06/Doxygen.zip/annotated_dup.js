var annotated_dup =
[
    [ "Button", "struct_button.html", null ],
    [ "Color", "struct_color.html", null ],
    [ "Heap", "struct_heap.html", null ],
    [ "MemDriver", "struct_mem_driver.html", null ],
    [ "PageResult", "struct_page_result.html", "struct_page_result" ],
    [ "PageState", "struct_page_state.html", "struct_page_state" ],
    [ "ParamStack", "struct_param_stack.html", "struct_param_stack" ],
    [ "Process", "struct_process.html", null ],
    [ "ProcessQueue", "struct_process_queue.html", null ],
    [ "program_linked_list_node", "structprogram__linked__list__node.html", null ],
    [ "RequestArgument", "union_request_argument.html", null ],
    [ "SchedulingInformation", "struct_scheduling_information.html", null ],
    [ "StackPointer", "union_stack_pointer.html", null ],
    [ "tlcdBuffer", "structtlcd_buffer.html", null ],
    [ "TouchEvent", "struct_touch_event.html", null ]
];