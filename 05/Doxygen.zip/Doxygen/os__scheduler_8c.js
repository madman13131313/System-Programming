var os__scheduler_8c =
[
    [ "idle", "os__scheduler_8c.html#a01131b63acf241e9db91704d89ce15d2", null ],
    [ "ISR", "os__scheduler_8c.html#a5686c229bdef50123688ab6cb1404230", null ],
    [ "os_dispatcher", "os__scheduler_8c.html#a5a646f82e9bcffc906b8f83227333cd3", null ],
    [ "os_enterCriticalSection", "os__scheduler_8c.html#a9d27b2dbf45ce6648916ed5ceb0a38df", null ],
    [ "os_exec", "os__scheduler_8c.html#ad28bcb8536fc0ff97a14bc452f993212", null ],
    [ "os_getCurrentProc", "os__scheduler_8c.html#a917313bbbb324677f26dfdf2ad80de3d", null ],
    [ "os_getProcessSlot", "os__scheduler_8c.html#aceff964882db0b41f7e2258ca4d16579", null ],
    [ "os_getSchedulingStrategy", "os__scheduler_8c.html#a4d9935433bba6ee89a4b3b31683d3184", null ],
    [ "os_getStackChecksum", "os__scheduler_8c.html#aaae9c0dde1e830325b558ebfce5864e8", null ],
    [ "os_initScheduler", "os__scheduler_8c.html#afcd3b8ded93499847533d52c2b08772a", null ],
    [ "os_kill", "os__scheduler_8c.html#ac495981d4e6fbcbc04d381dd69bf62d6", null ],
    [ "os_leaveCriticalSection", "os__scheduler_8c.html#a21546fdd22e5e6818e50856a119d98e0", null ],
    [ "os_setSchedulingStrategy", "os__scheduler_8c.html#ad3c4099c5ab03819e77f3de89a1174d2", null ],
    [ "os_startScheduler", "os__scheduler_8c.html#a51223e53b8c2474eeb097b532f167be8", null ],
    [ "os_yield", "os__scheduler_8c.html#a02d2fa79b4b720c7906a7262740db686", null ],
    [ "criticalSectionCount", "os__scheduler_8c.html#a3e46b6c5f8524eb09423304c15f9ed02", null ],
    [ "currentProc", "os__scheduler_8c.html#adb0cb32ce54e018ec562646256effc70", null ],
    [ "currSchedStrat", "os__scheduler_8c.html#ad27041c2a3c9f0fe802bc0c6e485080c", null ],
    [ "os_processes", "os__scheduler_8c.html#a583b140cea6b7a0bdc6ae1602b1459e2", null ]
];