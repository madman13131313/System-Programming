var searchData=
[
  ['extheap_5f_5f_507',['extHeap__',['../os__memheap__drivers_8c.html#a5fd7ae6e8a4b4961b8c925b2625c96b8',1,'extHeap__():&#160;os_memheap_drivers.c'],['../os__memheap__drivers_8h.html#a5fd7ae6e8a4b4961b8c925b2625c96b8',1,'extHeap__():&#160;os_memheap_drivers.c']]],
  ['extsram_5f_5f_508',['extSRAM__',['../os__mem__drivers_8c.html#af1c3e9f7bf5ac9163ab28d4070dc6894',1,'extSRAM__():&#160;os_mem_drivers.c'],['../os__mem__drivers_8h.html#af1c3e9f7bf5ac9163ab28d4070dc6894',1,'extSRAM__():&#160;os_mem_drivers.c']]]
];
